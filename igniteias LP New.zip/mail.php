<?php
include "vendor/autoload.php"; 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$message = '';
$path = 'upload/' . $_FILES["fileToUpload"]["name"];
 move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $path);
$mail = new PHPMailer;
 $mail->isMail();        //Sets Mailer to send message using SMTP
 $mail->Host = 'smtp.gmail.com';  //Sets the SMTP hosts of your Email hosting, this for Godaddy
 $mail->SMTPSecure = "tls";
 $mail->Port = '587';        //Sets the default SMTP server port
 $mail->SMTPAuth = true;       //Sets SMTP authentication. Utilizes the Username and Password variables
 $mail->Username = 'webroczsms@gmail.com';     //Sets SMTP username
 $mail->Password = 'SN!@#455';     //Sets SMTP password
 $mail->SMTPSecure = '';       //Sets connection prefix. Options are "", "ssl" or "tls"
 $mail->From = $_POST['email'];     //Sets the From email address for the message
 $mail->FromName = $_POST['name'];    //Sets the From name of the message
 $mail->AddAddress('rajeshkarne1@gmail.com', 'Us Medico MBBS');  //Adds a "To" address
 $mail->WordWrap = 50;       //Sets word wrapping on the body of the message to a given number of characters
 $mail->IsHTML(true);       //Sets message type to HTML
 //$mail->AddAttachment($_FILES['fileToUpload']['tmp_name'],$_FILES['fileToUpload']['name']);
 $mail->AddAttachment($path);     //Adds an attachment from a path on the filesystem
 $mail->Subject = 'Us Medico MBBS Appointment Form';    //Sets the Subject of the message
 $mail->Body = '<html><head><title>Us Medico MBBS Appointment Form</title></head><body>
 
 <table  border="1">
    <tr>
      <th>Name</th><th>Email</th><th>Mobile</th><th>Message</th>
    </tr>
    <tr>
      <td>'.$_POST['name'].'</td><td>'.$_POST['email'].'</td><td>'.$_POST['phone'].'</td><td>'.$_POST['message'].'</td>
    </tr>
  </table>
</body>
</html>';       //An HTML or plain text message body
 if($mail->Send())        //Send an Email. Return true on success or false on error
 {


 	                      // location.href = path+"/thank-you.html"

  $message = '<div class="alert alert-success">Application Successfully Submitted</div>';
  unlink($path);
   	            header('location: /mbbs/thank-you.html');
   }
 else
 {
  $message = '<div class="alert alert-danger">There is an Error</div>';
 }
  echo $message;
  
  

