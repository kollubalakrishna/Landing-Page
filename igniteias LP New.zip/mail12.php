<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$call = $_POST['call'];
$website = $_POST['website'];

$type = $_POST['type'];
$message = $_POST['message'];
$formcontent=" From: $name \n Phone: $phone \n Email: $email \n ";
$recipient = "adhityavarma656@gmail.com";
$subject = "  Ignite IAS Leads ";
$mailheader = "From: $email \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
header("Location:https://globalabroad.in/igniteias/admissions-open/thank-you.html");
?>