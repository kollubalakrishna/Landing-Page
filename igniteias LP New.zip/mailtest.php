<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $Course = $_POST["Course"];

    $to = "rajeshkarne1@gmail.com"; // Replace with your email address
    $subject = "Igniteias Form Lead";

    $mailBody = "Name: $name\n";
    $mailBody .= "Email: $email\n";
    $mailBody .= "phone:$phone\n";
    $mailBody .= "Course:$Course\n";

    // Send email
    mail($to, $subject, $mailBody);

    // Optionally, you can redirect the user to a thank you page
    header("Location: https://www.igniteias.com/admissions-open/thank-you.html");
    exit;
}

?>